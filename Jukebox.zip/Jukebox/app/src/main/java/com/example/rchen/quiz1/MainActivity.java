package com.example.rchen.quiz1;

import android.Manifest;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;


public class MainActivity extends Activity
{

    //instantiate the items in view
    public TextView songInfo, status;
    public ImageView albumArt;
    public Button buttonPlay, buttonStop, song1, song2, song3, song4;
    public MediaPlayer player = null;
    public SeekBar seekerBar;
    int SeekValue = 0;
    public String song = null;
    public MediaMetadataRetriever metaRetriver;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect items in view to controller
        songInfo = (TextView) findViewById(R.id.songInformationView);
        status = (TextView) findViewById(R.id.statusView);
        seekerBar = (SeekBar) findViewById(R.id.seekBar);
        albumArt = (ImageView) findViewById(R.id.albumArt);


        //Seeker Bar Tutorial - Setup Seeker Bar on Another Thread
        //Allows choice of location to play track
        //https://www.youtube.com/watch?v=f96OnSKprDw
        seekerBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                SeekValue = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {
                player.seekTo(SeekValue);
            }
        });

        SeekThread seekThread = new SeekThread();
        seekThread.start();



        //Request Permission to use External Storage from User
        //source: https://developer.android.com/training/permissions/requesting#java
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)
        {

            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE))
            {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else
            {
                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        1);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        } else
        {
            // Permission has already been granted
        }

    }

    //***********************Function For My Buttons**********************************


    //***************************play()***********************************************
    //Provides functionality for play button onClick method.
    //Play Music
    public void play(View view)
    {
        if (player == null)
        {
            player = new MediaPlayer();
        }
        try
        {
            //Reset music player
            player.reset();
            //Set Song
            player.setDataSource(song);
            //Prepare Music Async
            player.prepareAsync();

            //Upon Completion Stop the Player
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
            {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    stopPlayer();
                }
            });

            //Upon Preparation of Song Complete Start the Player
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
            {

                @Override
                public void onPrepared(MediaPlayer player)
                {
                    seekerBar.setMax(player.getDuration());
                    player.start();

                }

            });



        } catch (Exception e)
        {
            Log.e("Audio playback failure ", e.getMessage());
        }

        status.setText("Status: Playing");
    }

    //*************************stop()***********************************************
    //Provides functionality for play button onClick method.
    //Stop Music
    public void stop(View view)
    {
        stopPlayer();

    }

    //***************************playSong1()***********************************************
    //Provides functionality for play button onClick method.
    //Select Song 1
    public void playSong1(View view)
    {
        song = Environment.getExternalStorageDirectory().getPath() + "/Music/Adele - Hello.mp3";
        songInfo.setText("Adele - Hello");
        displayTrackInfo();
    }
    //***************************playSong2()***********************************************
    //Provides functionality for play button onClick method.
    //Select Song 2
    public void playSong2(View view)
    {
        song = Environment.getExternalStorageDirectory().getPath() + "/Music/Adele - Rolling In The Deep.mp3";
        songInfo.setText("Adele - Rolling In The Deep");
        displayTrackInfo();

    }

    //***************************playSong3()***********************************************
    //Provides functionality for play button onClick method.
    //Select Song 3
    public void playSong3(View view)
    {
        song = Environment.getExternalStorageDirectory().getPath() + "/Music/Adele - Set Fire To The Rain (Live at The Royal Albert Hall).mp3";
        songInfo.setText("Adele - Set Fire To The Rain ");
        displayTrackInfo();
    }

    //***************************playSong4()***********************************************
    //Provides functionality for play button onClick method.
    //Select Song 4
    public void playSong4(View view)
    {
        song = Environment.getExternalStorageDirectory().getPath() + "/Music/Beyond - Amani [HQ].mp3";
        songInfo.setText("Beyond - Amani ");
        displayTrackInfo();
    }

    //***********************Helper Functions**********************************

    //Code to display media meta information
    public void displayTrackInfo()
    {
        //Get Media Track Information
        //https://stackoverflow.com/questions/33360055/android-how-to-get-audio-detail-from-audio-file

        metaRetriver = new MediaMetadataRetriever();
        metaRetriver.setDataSource(song);
        byte[] art = new byte[0];

        String title;
        String album;
        String artist;
        String genre;
        try
        {
            art = metaRetriver.getEmbeddedPicture();
            Bitmap songImage = BitmapFactory
                    .decodeByteArray(art, 0, art.length);
            albumArt.setImageBitmap(songImage);
            title = metaRetriver.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);

            album = metaRetriver
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            artist = metaRetriver
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            genre = metaRetriver
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE);

        } catch (Exception e)
        {
            albumArt.setBackgroundColor(Color.GRAY);
            title = "Unknown Title";
            album = "Unknown Album";
            artist = "Unknown Artist";
            genre = "Unknown Genre";
        }
        
        if(art == null)
            albumArt.setBackgroundColor(Color.GRAY);
        if(title == null)
            title = "Unknown Title";
        if(album == null)
            album = "Unknown Album";
        if(artist == null)
            artist = "Unknown Artist";
        if(genre == null)
            genre = "Unknown Genre";
    
        String output = title + "\n" + album + "\n" + artist + "\n" + genre;
        songInfo.setText(output);
    }

    //Code to run whenever player is stopped
    public void stopPlayer()
    {
        if (player != null)
        {
            player.stop();
            player.release();
            player = null;
            SeekValue = 0;
            seekerBar.setProgress(SeekValue);
            status.setText("Status: Stopped");
        }
    }

    //When the application stops, stop the song from playing
    protected void onStop()
    {
        super.onStop();
        stopPlayer();
    }



    //A thread to manage the seeker bar
    class SeekThread extends Thread
    {
        public void run()
        {
            while (true)
            {
                try
                {
                    Thread.sleep(1000);

                } catch (Exception e)
                {
                    e.printStackTrace();
                }

                runOnUiThread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if(player!=null)
                        {
                            seekerBar.setProgress(player.getCurrentPosition());
                        }
                    }
                });
            }
        }
    }
}